module.exports = {
  presets: [
    '@vue/babel-preset-jsx'
  ]
}