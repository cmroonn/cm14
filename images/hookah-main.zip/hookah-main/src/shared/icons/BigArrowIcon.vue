<template>
  <svg
    width="216"
    height="47"
    viewBox="0 0 216 47"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M0 23.5H215M215 23.5L193.698 1M215 23.5L193.698 46"
      stroke="#45403D"
    />
  </svg>
</template>
