<template>
  <svg
    width="41"
    height="42"
    viewBox="0 0 41 42"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M0 21H40M40 21L21.0651 1M40 21L21.0651 41" stroke="#45403D" />
  </svg>
</template>
