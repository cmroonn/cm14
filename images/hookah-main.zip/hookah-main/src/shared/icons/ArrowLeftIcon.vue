<template>
  <svg
    width="41"
    height="42"
    viewBox="0 0 41 42"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M41 21H0.999999M0.999999 21L19.9349 1M0.999999 21L19.9349 41"
      stroke="#45403D"
    />
  </svg>
</template>
