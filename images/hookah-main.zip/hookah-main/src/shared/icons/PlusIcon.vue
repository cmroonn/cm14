<template>
  <svg
    width="45"
    height="45"
    viewBox="0 0 45 45"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M22.05 45L22.05 0M0 22.05L45 22.05" />
  </svg>
</template>
