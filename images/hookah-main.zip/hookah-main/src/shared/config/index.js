export const links = [
  { url: "/", title: "Кальян на дом" },
  { url: "/catering", title: "кейтеринг" },
  { url: "/delivery", title: "Доставка фруктовых чаш" },
  { url: "/manual", title: "Инструкция" },
  { url: "/partners", title: "партнёрам" },
  { url: "/contacts", title: "Контакты" },
];
