import Main from "./ui/Main.vue";

export { Main };
