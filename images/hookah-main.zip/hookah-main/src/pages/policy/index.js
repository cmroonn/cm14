import Policy from "./ui/Policy.vue";

export { Policy };
