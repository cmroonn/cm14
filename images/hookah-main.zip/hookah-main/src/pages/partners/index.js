import Partners from "./ui/Partners.vue";

export { Partners };
