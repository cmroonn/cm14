import Contacts from "./ui/Contacts.vue";

export { Contacts };
