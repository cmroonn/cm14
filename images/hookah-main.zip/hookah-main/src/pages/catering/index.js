import Catering from "./ui/Catering.vue";

export { Catering };
