<script setup>
import { TelegramIcon } from "@/shared/icons";
import { WhatsappIcon } from "@/shared/icons";
import { Button } from "@/shared/ui/button";
import { KinesisContainer, KinesisElement } from "vue-kinesis";
</script>

<template>
  <div class="cost">
    <div class="container">
      <div class="cost-inner">
        <h3>Стоимость</h3>
        <div class="cost-about">
          <div class="cost-about-item">
            <span>Чаша меняется раз в 50 минут</span>
            <p>
              либо по первому требованию клиента (не зашло по вкусу, горчит и
              прочее)
            </p>
          </div>
          <div class="cost-about-item">
            <span
              >Оплата услуг наличными <br />
              либо на расчетный счет</span
            >
          </div>
        </div>
        <div class="cost-content">
          <div class="cost-content-item">
            <h5>1 кальян На глиняной чаше <span>1 200 ₽ / час</span></h5>
            <p>Минимальный заказ — от 3-х часов</p>
          </div>
          <div class="cost-content-item">
            <div class="image-wrapper">
              <img src="@/shared/assets/images/cost/1.jpg" alt="photo" />
            </div>
            <h5>На грейпфруте</h5>
            <span>+ 300 ₽</span>
          </div>
          <div class="cost-content-item">
            <div class="image-wrapper">
              <img src="@/shared/assets/images/cost/2.jpg" alt="photo" />
            </div>
            <h5>стоимость На других фруктах</h5>
            <span>по запросу</span>
          </div>
        </div>
        <div class="cost-info">
          <div class="contacts">
            <a href="tel:8 800 000-00-00">8 800 000-00-00</a>
            <div class="socials">
              <a
                href="https://t.me/hookahtohome"
                target="_blank"
                class="social tg"
              >
                <TelegramIcon />
              </a>
              <a
                href="https://wa.me/+79165993923"
                target="_blank"
                class="social wa"
              >
                <WhatsappIcon />
              </a>
            </div>
            <Button variable="primary"> заказать кейтеринг </Button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
@import "@/shared/styles/vars";

.cost {
  background: var(--white-color);
  padding-top: 130px;
  @media (max-width: $tab) {
    padding-top: 80px;
  }
  .cost-inner {
    h3 {
      font-weight: 400;
      font-size: 64px;
      line-height: 54px;
      color: var(--text-color);
      position: relative;
      padding-left: 70px;
      text-transform: uppercase;
      letter-spacing: -2px;

      @media (max-width: $tab) {
        font-size: 35px;
        line-height: 29px;
        padding-left: 40px;
      }
      &:before {
        position: absolute;
        content: "";
        width: 45px;
        height: 45px;
        background: var(--text-color);
        border-radius: 999px;
        left: 0;
        top: 0;
        bottom: 0;
        margin: auto;
        @media (max-width: $tab) {
          width: 30px;
          height: 30px;
        }
      }
    }
    .cost-about {
      display: flex;
      margin-top: 50px;
      gap: 20px;
      @media (max-width: $tab-sm) {
        flex-direction: column;
      }
      .cost-about-item {
        width: 50%;
        border-left: 1px solid var(--text-color);
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        @media (max-width: $tab-sm) {
          width: 100%;
        }
        &:first-child {
          padding-left: 38px;
        }
        &:last-child {
          padding-left: 29px;
        }
        span {
          font-weight: 400;
          font-size: 32px;
          line-height: 35px;
          color: var(--text-color);
          text-transform: uppercase;
          @media (max-width: $tab) {
            font-size: 24px;
            line-height: 26px;
          }
        }
        p {
          font-weight: 400;
          font-size: 16px;
          line-height: 20px;
          color: var(--text-color);
        }
      }
    }
    .cost-content {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 20px;
      margin-top: 50px;
      @media (max-width: $tab) {
        grid-template-columns: repeat(1, 1fr);
        gap: 40px;
      }
      .cost-content-item {
        height: fit-content;
        width: 100%;
        &:first-child {
          padding-top: 50px;
          border-top: 1px solid var(--text-color);
          padding-left: 30px;
          @media (max-width: $tab) {
            padding-left: 0;
          }
          p {
            font-weight: 400;
            font-size: 16px;
            line-height: 20px;
            color: var(--text-color);
            padding-left: 35px;
            margin-top: 20px;
          }
        }
        .image-wrapper {
          width: 100%;
          height: 100%;
          @media (max-width: $tab) {
            margin-bottom: 20px;
          }
          img {
            width: 100%;
            height: 100%;
            object-fit: cover;
          }
        }
        h5 {
          position: relative;
          font-weight: 400;
          font-size: 24px;
          line-height: 26px;
          color: var(--text-color);
          display: flex;
          flex-direction: column;
          text-transform: uppercase;
          @media (max-width: $tab) {
            font-size: 20px;
            line-height: 22px;
          }
          &:first-child {
            padding-left: 35px;
            &:before {
              content: "";
              position: absolute;
              border-radius: 999px;
              border: 1px solid var(--text-color);
              width: 20px;
              height: 20px;
              top: 4px;
              left: 0;
              @media (max-width: $tab) {
                width: 12px;
                height: 12px;
              }
            }
          }

          span {
            font-weight: 600;
            font-size: 24px;
            line-height: 26px;
            @media (max-width: $tab) {
              font-size: 20px;
              line-height: 22px;
            }
          }
        }
        p {
          font-weight: 400;
          font-size: 24px;
          line-height: 26px;
          color: var(--text-color);
          margin-top: 20px;
          @media (max-width: $tab) {
            font-size: 16px;
            line-height: 20px;
          }
        }
        span {
          font-weight: 600;
          font-size: 24px;
          line-height: 26px;
          color: var(--text-color);
          text-transform: uppercase;
          display: block;
        }
      }
    }
    .cost-info {
      padding-top: 50px;
      margin-top: 50px;
      border-top: 1px solid var(--text-color);
      padding-left: 35px;
      padding-bottom: 150px;
      @media (max-width: $tab) {
        padding-bottom: 80px;
        padding-left: 0;
      }
      @media (max-width: $tab-sm) {
        margin-top: 20px;
      }
      .contacts {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 37px;

        max-width: 640px;
        @media (max-width: $tab-sm) {
          width: 100%;
          flex-wrap: wrap;
        }
        & > button {
          white-space: nowrap;
          @media (max-width: $tab-sm) {
            width: 100%;
          }
        }
        a {
          font-weight: 600;
          font-size: 24px;
          line-height: 24px;
          letter-spacing: -2px;
          white-space: nowrap;
          color: var(--text-color);
          @media (max-width: $tab-sm) {
            font-size: 24px;
            line-height: 24px;
          }
        }
        .socials {
          display: flex;
          align-items: center;
          gap: 10px;
          a {
            width: 60px;
            height: 60px;
            @media (max-width: $tab-sm) {
              width: 50px;
              height: 50px;
            }
          }
        }
      }
    }
  }
}
</style>
