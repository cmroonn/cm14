import Delivery from "./ui/Delivery.vue";

export { Delivery };
