import Manual from "./ui/Manual.vue";

export { Manual };
