import Footer from "./ui/Footer.vue";

export { Footer };
