import Stamps from "./ui/Stamps.vue";

export { Stamps };
