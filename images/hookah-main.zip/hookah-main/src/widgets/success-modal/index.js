import SuccessModal from "./ui/SuccessModal.vue";

export { SuccessModal };
