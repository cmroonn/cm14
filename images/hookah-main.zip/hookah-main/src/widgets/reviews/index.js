import Reviews from "./ui/Reviews.vue";

export { Reviews };
