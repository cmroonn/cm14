import Fancybox from "./ui/Fancybox.vue";

export { Fancybox };
