import Hero from './ui/Hero.vue'

export { Hero }