export const costList = [
  {
    id: 1,
    title: "На глиняной чаше",
    cost: "1 900 ₽",
    addTitle: "Доп чаша",
    addCost: "600 ₽",
  },
  {
    id: 2,
    title: "На грейпфруте",
    cost: "1 900 ₽",
    addTitle: "Доп чаша",
    addCost: "800 ₽",
  },
  {
    id: 3,
    title: "На гранате",
    cost: "2 300 ₽",
    addTitle: "Доп чаша",
    addCost: "900 ₽",
  },
  {
    id: 4,
    title: "На помело",
    cost: "2 400 ₽",
    addTitle: "Доп чаша",
    addCost: "1 200 ₽",
  },
  {
    id: 5,
    title: "На ананасе",
    cost: "2 400 ₽",
    addTitle: "Доп чаша",
    addCost: "1 400 ₽",
  },
];
