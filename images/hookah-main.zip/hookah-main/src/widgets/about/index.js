import About from "./ui/About.vue";

export { About };
