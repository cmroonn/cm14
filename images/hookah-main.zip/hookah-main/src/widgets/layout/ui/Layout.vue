<script>
import { Header } from "@/widgets/header";
import { Footer } from "@/widgets/footer";
</script>

<template>
  <Header />
  <slot></slot>
  <Footer />
</template>
