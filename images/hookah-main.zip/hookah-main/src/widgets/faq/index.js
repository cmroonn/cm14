import Faq from "./ui/Faq.vue";

export { Faq };
