import ManualSwiper from "./ui/ManualSwiper.vue";

export { ManualSwiper };
