import HeroSwiper from "./ui/HeroSwiper.vue";

export { HeroSwiper };
