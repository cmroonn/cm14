import StampsSwiper from "./ui/StampsSwiper.vue";

export { StampsSwiper };
