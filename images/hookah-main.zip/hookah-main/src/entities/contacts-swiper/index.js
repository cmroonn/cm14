import ContactsSwiper from "./ui/ContactsSwiper.vue";

export { ContactsSwiper };
