import PartnersSwiper from "./ui/PartnersSwiper.vue";

export { PartnersSwiper };
